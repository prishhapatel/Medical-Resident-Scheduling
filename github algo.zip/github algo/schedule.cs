//
//
//
//

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Collections;

class Scheduler
{
    
    // inputs
    static PGY1 LoadPGY1(int id)
    {
        // get name, role, vacation days 
        if(id == 0)
        {
            PGY1 resident = new PGY1("Samantha Berner-Cronin");
            resident.rolePerMonth[0] = HospitalRole.EmergencyMed; // july they are psych consult
            resident.rolePerMonth[1] = HospitalRole.Neurology; // august they are inpatient psych
            return resident;
        }
        if(id == 1)
        {
            PGY1 resident = new PGY1("Carolyn Lara Coles");
            resident.rolePerMonth[0] = HospitalRole.Inpatient; 
            resident.rolePerMonth[1] = HospitalRole.Inpatient; 
            return resident;
        }
        if(id == 2)
        {
            PGY1 resident = new PGY1("Ninoshka Rosalyn Hidalgo Martinez");
            resident.rolePerMonth[0] = HospitalRole.Inpatient; 
            resident.rolePerMonth[1] = HospitalRole.PsychConsults; 
            return resident;
        }
        if(id == 3)
        {
            PGY1 resident = new PGY1("Cody James Holland");
            resident.rolePerMonth[0] = HospitalRole.Inpatient; 
            resident.rolePerMonth[1] = HospitalRole.Inpatient; 
            return resident;
        }
        if(id == 4)
        {
            PGY1 resident = new PGY1("Lawrence Chun To Ku");
            resident.rolePerMonth[0] = HospitalRole.Neurology; 
            resident.rolePerMonth[1] = HospitalRole.IMOutpatient; 
            return resident;
        }
        if(id == 5)
        {
            PGY1 resident = new PGY1("Pooja Sanat Patel");
            resident.rolePerMonth[0] = HospitalRole.IMOutpatient; 
            resident.rolePerMonth[1] = HospitalRole.IMInpatient; 
            return resident;
        }  
        if(id == 6)
        {
            PGY1 resident = new PGY1("Roshni Patel");
            resident.rolePerMonth[0] = HospitalRole.PsychConsults; 
            resident.rolePerMonth[1] = HospitalRole.Inpatient; 
            return resident;
        }
        if(id == 7)
        {
            PGY1 resident = new PGY1("Lauren Maria Rafanan");
            resident.rolePerMonth[0] = HospitalRole.Neurology; 
            resident.rolePerMonth[1] = HospitalRole.EmergencyMed; 
            return resident;
        }
        return null;
    }
    static PGY2 LoadPGY2(int id)
    {
        // get name, role, vacation days 
        if(id == 0)
        {
            PGY2 resident = new PGY2("Melissa Chen");
            resident.rolePerMonth[0] = HospitalRole.Addiction; // july they are psych consult
            resident.rolePerMonth[1] = HospitalRole.CAP; // august they are inpatient psych
            return resident;
        }
        if(id == 1)
        {
            PGY2 resident = new PGY2("Malissa Descalzo");
            resident.rolePerMonth[0] = HospitalRole.NightFloat; 
            resident.rolePerMonth[1] = HospitalRole.Inpatient; 
            return resident;
        }
        if(id == 2)
        {
            PGY2 resident = new PGY2("Haley Danielle Gallaher");
            resident.rolePerMonth[0] = HospitalRole.Inpatient; 
            resident.rolePerMonth[1] = HospitalRole.NightFloat; 
            return resident;
        }
        if(id == 3)
        {
            PGY2 resident = new PGY2("Felix Adrian Hernandez Perez");
            resident.rolePerMonth[0] = HospitalRole.CAP; 
            resident.rolePerMonth[1] = HospitalRole.CAP; 
            return resident;
        }
        if(id == 4)
        {
            PGY2 resident = new PGY2("Haider Khan");
            resident.rolePerMonth[0] = HospitalRole.NightFloat; 
            resident.rolePerMonth[1] = HospitalRole.Geriatric; 
            return resident;
        }
        if(id == 5)
        {
            PGY2 resident = new PGY2("Rachel Penumudi");
            resident.rolePerMonth[0] = HospitalRole.Geriatric; 
            resident.rolePerMonth[1] = HospitalRole.NightFloat; 
            return resident;
        }  
        if(id == 6)
        {
            PGY2 resident = new PGY2("Alexis Mitra Shahidi");
            resident.rolePerMonth[0] = HospitalRole.CommP; 
            resident.rolePerMonth[1] = HospitalRole.Forensic; 
            return resident;
        }
        if(id == 7)
        {
            PGY2 resident = new PGY2("Insherah Sughayer");
            resident.rolePerMonth[0] = HospitalRole.Forensic; 
            resident.rolePerMonth[1] = HospitalRole.Addiction; 
            return resident;
        }
        return null;
    }
    static PGY3 LoadPGY3(int id)
    {
        // get name, vacation days 
        if(id == 0)
        {
            PGY3 resident = new PGY3("Anne-Sophie Attoungbre");
            return resident;
        }
        if(id == 1)
        {
            PGY3 resident = new PGY3("Kendall Kelsey Beltran");
            return resident;
        }
        if(id == 2)
        {
            PGY3 resident = new PGY3("Hanna Castano");
            return resident;
        }
        if(id == 3)
        {
            PGY3 resident = new PGY3("Tyler Michael Halbig");
            return resident;
        }
        if(id == 4)
        {
            PGY3 resident = new PGY3("Gautam Kanakamedala");
            return resident;
        }
        if(id == 5)
        {
            PGY3 resident = new PGY3("Lekhya Kintada");
            return resident;
        }  
        if(id == 6)
        {
            PGY3 resident = new PGY3("Stephany Mejias Urrutia");
            return resident;
        }
        if(id == 7)
        {
            PGY3 resident = new PGY3("Reema Shailesh Patel");
            return resident;
        }
        return null;
    }

    static void Training(int year)
    {
        int pgy1 = 8;
        int pgy2 = 8;
        int pgy3 = 8;
        ArrayList AllPgy1s = new ArrayList();
        ArrayList AllPgy2s = new ArrayList();
        ArrayList AllPgy3s = new ArrayList();
        for(int i = 0; i < pgy1; i++)
        {
            AllPgy1s.Add(LoadPGY1(i));
            AllPgy2s.Add(LoadPGY2(i));
            AllPgy3s.Add(LoadPGY3(i));
        }
        TrainingCalendar tCalendar = new TrainingCalendar(year);
        
        int Sat24hCallAmt = tCalendar.dayOfWeekAmt[6]; // how many saturday calls for training
        int Sun12hCallAmt = tCalendar.dayOfWeekAmt[0]; // how many sunday calls
        int shortCallAmt =  tCalendar.dayOfWeekAmt[2] + tCalendar.dayOfWeekAmt[3] + tCalendar.dayOfWeekAmt[4]; // t + w + th

        // make sure a pgy1 is with a pgy3 3 times for a short call
        int nodeAmt = (shortCallAmt * 2) /* split node */ + pgy3 + pgy1 + 2 /*source & sink*/; // !!!!node id order!!!!
        int sourceIndex = nodeAmt - 2; // -2 for 0 indexing
        int sinkIndex = nodeAmt - 1; 

        Graph shortCallGraph = new Graph(nodeAmt);
        for(int i = 0; i < pgy1; i++)
        {
            shortCallGraph.addEdge(sourceIndex, (shortCallAmt * 2 + pgy3 + i), 3); //source node, pgy1 index, days pgy1s need to work
        }

        for(int i = 0; i < pgy1; i++) 
        {
            for(int j = 0; j < shortCallAmt; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                // what month are we in
                int month = (int) (tCalendar.whatShortDayIsIt(j).Month);
                // DEBUG Console.WriteLine(month);

                //are we in july?
                if(month == 7)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[0].doesShort == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[0].flexShort == false) // if their role doesnt do short calls this month
                    {
                        continue; // then skip over them and dont add the edge because they cant be used
                    }
                }
                // are we in august?
                if(month == 8)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[1].doesShort == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[1].flexShort == false)
                    {
                        continue; // same as above
                    }
                }
                shortCallGraph.addEdge((shortCallAmt * 2 + pgy3 + i), 2*j, 1); //each pgy1 has an edge between them and a training day
            }
        }

        for(int i = 0; i < shortCallAmt; i++)
        {
            shortCallGraph.addEdge(i*2, (i*2+1), 1); // connecting split nodes.
        }
        
        for(int i = 0; i < shortCallAmt; i++) 
        {
            for(int j = 0; j < pgy3; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                shortCallGraph.addEdge((i*2+1), (shortCallAmt * 2) + j, 1); //each pgy3 can only train once per day
            }
        }
        
        int estPgy3Training = ((3*pgy1+pgy3-1)/pgy3); // ceiling division to get capacity amount for sink
        for(int i = 0; i < pgy3; i++)
        {
            shortCallGraph.addEdge((shortCallAmt * 2) + i, sinkIndex, estPgy3Training);
        }

        if (shortCallGraph.getFlow(sourceIndex, sinkIndex) != 3 * pgy1)
        {
            Console.WriteLine("[ERROR] Not able to make valid assignment based on parameters");
        }
        else 
        {
            Console.WriteLine("Succesfully created pgy3 training assignment");
            Console.WriteLine("PGY1 Assignments:");
            for (int i = 0; i < pgy1; i++)
            {
                Console.WriteLine($" PGY1 #{((PGY1)(AllPgy1s[i])).name}:");
                ArrayList curList = (ArrayList)(shortCallGraph.adjList[(shortCallAmt * 2) + pgy3 + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if flow is leaving the current edge
                    if (currEdge.flow() > 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatShortDayIsIt(currEdge.destination/2)}");
                    }
                }
            }

            Console.WriteLine("PGY3 Assignments:");
            for (int i = 0; i < pgy3; i++)
            {
                Console.WriteLine($" PGY3 #{((PGY3)(AllPgy3s[i])).name}");
                ArrayList curList = (ArrayList)(shortCallGraph.adjList[(shortCallAmt * 2) + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if the flow is negative
                    if (currEdge.flow() < 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatShortDayIsIt(currEdge.destination/2)}");
                    }
                }
            }
        }

        // make sure a pgy1 is with a pgy2 on a 24h saturday 
        nodeAmt = (Sat24hCallAmt * 2) /* split node */ + pgy2 + pgy1 + 2 /*source & sink*/; // !!!!node id order!!!!
        sourceIndex = nodeAmt - 2; // -2 for 0 indexing
        sinkIndex = nodeAmt - 1; 
        Graph saturdayCallGraph = new Graph(nodeAmt);
        for(int i = 0; i < pgy1; i++)
        {
            saturdayCallGraph.addEdge(sourceIndex, (Sat24hCallAmt * 2 + pgy2 + i), 1); //source node, pgy1 index, days pgy1s need to work
        }

        for(int i = 0; i < pgy1; i++) 
        {
            for(int j = 0; j < Sat24hCallAmt; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                // what month are we in
                int month = (int) (tCalendar.whatSaturdayIsIt(j).Month);
                // DEBUG Console.WriteLine(month);

                //are we in july?
                if(month == 7)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[0].doesLong == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[0].flexLong == false) // if their role doesnt do long calls this month
                    {
                        continue; // then skip over them and dont add the edge because they cant be used
                    }
                }
                // are we in august?
                if(month == 8)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[1].doesLong == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[1].flexLong == false)
                    {
                        continue; // same as above
                    }
                }
                saturdayCallGraph.addEdge((Sat24hCallAmt * 2 + pgy2 + i), 2*j, 1); //each pgy1 has an edge between them and a training day
            }
        }

        for(int i = 0; i < Sat24hCallAmt; i++)
        {
            saturdayCallGraph.addEdge(i*2, (i*2+1), 1); // connecting split nodes.
        }
        
        for(int i = 0; i < pgy2; i++) 
        {
            for(int j = 0; j < Sat24hCallAmt; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                // what month are we in
                int month = (int) (tCalendar.whatSaturdayIsIt(j).Month);
                // DEBUG Console.WriteLine(month);

                //are we in july?
                if(month == 7)
                {
                    if(((PGY2)(AllPgy2s[i])).rolePerMonth[0].doesLong == false && ((PGY2)(AllPgy2s[i])).rolePerMonth[0].flexLong == false) // if their role doesnt do long calls this month
                    {
                        continue; // then skip over them and dont add the edge because they cant be used
                    }
                }
                // are we in august?
                if(month == 8)
                {
                    if(((PGY2)(AllPgy2s[i])).rolePerMonth[1].doesLong == false && ((PGY2)(AllPgy2s[i])).rolePerMonth[1].flexLong == false)
                    {
                        continue; // same as above
                    }
                }
                saturdayCallGraph.addEdge(2*i + 1,(Sat24hCallAmt * 2) + j, 1); //each pgy2 can only train once per day
                //source node, pgy2 index, days pgy1s need to work
            }
        }
        int estPgy2Training = ((pgy1+pgy2-1)/pgy2); // ceiling division to get capacity amount for sink
        for(int i = 0; i < pgy2; i++)
        {
            saturdayCallGraph.addEdge((Sat24hCallAmt * 2) + i, sinkIndex, estPgy2Training);
        }
        int flow = saturdayCallGraph.getFlow(sourceIndex, sinkIndex);
        Console.WriteLine($"The flow is {flow}");
        Console.WriteLine($"The number of pgy1 is {pgy1}");
        if (flow != 1 * pgy1)
        {
            Console.WriteLine("[ERROR] Not able to make valid assignment based on parameters");
        }
        else
        {
            Console.WriteLine("Succesfully created PGY2 training assignment");
            Console.WriteLine("PGY1 Assignments:");
            for (int i = 0; i < pgy1; i++)
            {
                Console.WriteLine($" PGY1 #{((PGY1)(AllPgy1s[i])).name}:");
                ArrayList curList = (ArrayList)(saturdayCallGraph.adjList[(Sat24hCallAmt * 2) + pgy2 + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if flow is leaving the current edge
                    if (currEdge.flow() > 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatSaturdayIsIt(currEdge.destination/2)}");
                    }
                }
            }

            Console.WriteLine("PGY2 Assignments:");
            for (int i = 0; i < pgy2; i++)
            {
                Console.WriteLine($" PGY2 #{((PGY2)(AllPgy2s[i])).name}");
                ArrayList curList = (ArrayList)(saturdayCallGraph.adjList[(Sat24hCallAmt * 2) + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if the flow is negative
                    if (currEdge.flow() < 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatSaturdayIsIt(currEdge.destination/2)}");
                    }
                }
            }

        }

        // make sure a pgy1 is with a pgy2 on a 12h sunday
        nodeAmt = (Sun12hCallAmt * 2) /* split node */ + pgy2 + pgy1 + 2 /*source & sink*/; // !!!!node id order!!!!
        sourceIndex = nodeAmt - 2; // -2 for 0 indexing
        sinkIndex = nodeAmt - 1; 
        Graph sundaysCallGraph = new Graph(nodeAmt);
     
        for(int i = 0; i < pgy1; i++)
        {
            sundaysCallGraph.addEdge(sourceIndex, (Sun12hCallAmt * 2 + pgy2 + i), 1); //source node, pgy1 index, days pgy1s need to work
        }

        for(int i = 0; i < pgy1; i++) 
        {
            for(int j = 0; j < Sun12hCallAmt; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                // what month are we in
                int month = (int) (tCalendar.whatSundayIsIt(j).Month);
                // DEBUG Console.WriteLine(month);

                //are we in july?
                if(month == 7)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[0].doesLong == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[0].flexLong == false) // if their role doesnt do long calls this month
                    {
                        continue; // then skip over them and dont add the edge because they cant be used
                    }
                }
                // are we in august?
                if(month == 8)
                {
                    if(((PGY1)(AllPgy1s[i])).rolePerMonth[1].doesLong == false && ((PGY1)(AllPgy1s[i])).rolePerMonth[1].flexLong == false)
                    {
                        continue; // same as above
                    }
                }
                sundaysCallGraph.addEdge((Sun12hCallAmt * 2 + pgy2 + i), 2*j, 1); //each pgy1 has an edge between them and a training day
            }
        }

        for(int i = 0; i < Sun12hCallAmt; i++)
        {
            sundaysCallGraph.addEdge(i*2, (i*2+1), 1); // connecting split nodes. OTHERWISE THERE WOULD BE 0 FLOW IN THE GRAPH
        }
        
        for(int i = 0; i < pgy2; i++) 
        {
            for(int j = 0; j < Sun12hCallAmt; j++) // TO DO: THIS IS WHERE VACATION TIME WILL GO!!!!
            {
                // what month are we in
                int month = (int) (tCalendar.whatSundayIsIt(j).Month);
                // DEBUG Console.WriteLine(month);

                //are we in july?
                if(month == 7)
                {
                    if(((PGY2)(AllPgy2s[i])).rolePerMonth[0].doesLong == false && ((PGY2)(AllPgy2s[i])).rolePerMonth[0].flexLong == false) // if their role doesnt do long calls this month
                    {
                        continue; // then skip over them and dont add the edge because they cant be used
                    }
                }
                // are we in august?
                if(month == 8)
                {
                    if(((PGY2)(AllPgy2s[i])).rolePerMonth[1].doesLong == false && ((PGY2)(AllPgy2s[i])).rolePerMonth[1].flexLong == false)
                    {
                        continue; // same as above
                    }
                }
                sundaysCallGraph.addEdge(2*i + 1,(Sun12hCallAmt * 2) + j, 1); //each pgy2 can only train once per day
                //source node, pgy2 index, days pgy1s need to work
            }
        }
        //int estPgy2Training = ((pgy1+pgy2-1)/pgy2); // ceiling division to get capacity amount (estimated amount of time pgy2 must train someone) for sink
        for(int i = 0; i < pgy2; i++)
        {
            sundaysCallGraph.addEdge((Sun12hCallAmt * 2) + i, sinkIndex, estPgy2Training);
        }

        if (sundaysCallGraph.getFlow(sourceIndex, sinkIndex) != 1 * pgy1)
        {
            Console.WriteLine("[ERROR] Not able to make valid assignment based on parameters");
        }
        else
        {
            Console.WriteLine("Succesfully created Sunday PGY2 training assignment");
            Console.WriteLine("PGY1 Assignments:");
            for (int i = 0; i < pgy1; i++)
            {
                Console.WriteLine($" PGY1 #{((PGY1)(AllPgy1s[i])).name}:");
                ArrayList curList = (ArrayList)(sundaysCallGraph.adjList[(Sun12hCallAmt * 2) + pgy2 + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if flow is leaving the current edge
                    if (currEdge.flow() > 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatSundayIsIt(currEdge.destination/2)}");
                    }
                }
            }

            Console.WriteLine("PGY2 Assignments:");
            for (int i = 0; i < pgy2; i++)
            {
                Console.WriteLine($" PGY2 #{((PGY2)(AllPgy2s[i])).name}");
                ArrayList curList = (ArrayList)(sundaysCallGraph.adjList[(Sun12hCallAmt * 2) + i]);
                for (int j = 0; j < curList.Count; j++)
                {
                    Edge currEdge = (Edge)(curList[j]);
                    // check if the flow is negative
                    if (currEdge.flow() < 0)
                    {
                        Console.WriteLine($"  Day {tCalendar.whatSundayIsIt(currEdge.destination/2)}");
                    }
                }
            }

        }

    }
    static void Main()
    {
        int year = 2025; // hardcoded for now, get from user later

        Training(year);

        /*
        // inputs
        int residentsAmt = getResidents();
        
        // IF scheduling starts in july, call training()

        // part of hospital and vacation day per resident
        for(int i = 0; i < residentsAmt; i++)
        {

        }
        */
    }
}

// example
/*
    
*/

// other things to consider : pgy year and where in hospital they work 
// month by month, positions in hospital change. which means that we will probably have to schedule month by month (at least in the back end)

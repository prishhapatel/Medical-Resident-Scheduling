using System;
using System.Collections.Generic;

class HospitalRole
{
    public bool doesShort { get; }
    public bool doesLong { get; }
    public bool flexShort { get; } // flexible short, this role will allow exceptions to be made during trainings or anywhere else necessary
    public bool flexLong { get; } // flexible long
    
    private HospitalRole(bool doesShort, bool doesLong, bool flexShort, bool flexLong)
    {
        this.doesShort = doesShort;
        this.doesLong = doesLong;
        this.flexShort = flexShort;
        this.flexLong = flexLong;
    }
    public static readonly HospitalRole Inpatient = new HospitalRole(true, true, false, false);
    public static readonly HospitalRole Geriatric = new HospitalRole(true, true, false, false);
    public static readonly HospitalRole PHPandIOP = new HospitalRole(true, true, false, false);
    public static readonly HospitalRole PsychConsults = new HospitalRole(true, true, false, false);
    
    // come back to this bc wtf NightFloatandCL
    public static readonly HospitalRole CommP = new HospitalRole(false, true, false, false);
    public static readonly HospitalRole CAP = new HospitalRole(false, true, false, false);
    public static readonly HospitalRole Addiction = new HospitalRole(false, true, false, false);
    public static readonly HospitalRole Forensic = new HospitalRole(false, true, false, false);
    public static readonly HospitalRole Float = new HospitalRole(false, true, false, false);
    public static readonly HospitalRole Neurology = new HospitalRole(false, true, true, false);
    public static readonly HospitalRole IMOutpatient = new HospitalRole(false, true, true, false);
    public static readonly HospitalRole IMInpatient = new HospitalRole(false, false, false, true);
    public static readonly HospitalRole NightFloat = new HospitalRole(false, false, false, false); // is this really separate from night float/cl
    public static readonly HospitalRole EmergencyMed = new HospitalRole(false, false, false, true);
}


using System;
using System.Collections.Generic;
using System.Globalization;
using System.Collections;

class PGY2
{
    // name, vacation, hours DO THEY HAVE HOSPITAL ROLES?
    public string name; // public to be accessible outside the class
    public HospitalRole[] rolePerMonth; // the PGY2's role per month
    ArrayList vacationRequests; 
    ArrayList allWorkDates; // every single day they are supposed to work
    
    int hoursWorked6months;
    int hoursWorkedTotal;

    public PGY2(string name)
    {
        this.name = name;
        rolePerMonth = new HospitalRole[12]; //dynamic memory allocation in c#
        vacationRequests = new ArrayList();
        hoursWorked6months = 0; hoursWorkedTotal = 0;
    }
}
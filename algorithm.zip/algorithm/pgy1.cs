
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Collections;

class PGY1
{
    // name, vacation, hours DO THEY HAVE HOSPITAL ROLES?
    public string name; // public to be accessible outside the class
    public HospitalRole[] rolePerMonth; // the PGY1's role per month
    ArrayList vacationRequests; 
    ArrayList allWorkDates; // every single day they are supposed to work
    
    int hoursWorked6months; // database
    int hoursWorkedTotal;

    int inTraining;
    public PGY1(string name)
    {
        this.name = name;
        rolePerMonth = new HospitalRole[12]; //dynamic memory allocation in c#
        vacationRequests = new ArrayList();
        hoursWorked6months = 0; hoursWorkedTotal = 0;
        inTraining = 1; // move to 0 after all training complete
    }
}
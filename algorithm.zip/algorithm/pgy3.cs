
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Collections;

class PGY3
{
    // name, vacation, hours DO THEY HAVE HOSPITAL ROLES?
    public string name; // public to be accessible outside the class
    ArrayList vacationRequests; 
    ArrayList allWorkDates; // every single day they are supposed to work
    
    int hoursWorked6months;
    int hoursWorkedTotal;
    public PGY3(string name)
    {
        this.name = name;
        vacationRequests = new ArrayList();
        hoursWorked6months = 0; hoursWorkedTotal = 0;
    }
}